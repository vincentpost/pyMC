"""
This file is a basic Python program that displays a message on the screen.
The contents of the message vary depending on the name provided.

"""

name = "YourName"

if name == "Vincent":
    print("Vincent is one of the instructors of the Python Masterclass")
elif name == "Anushree":
    print("Anushree is the AWS support person during the Python Masterclass")
else:
    print("Name is unknown, not sure what to print about this person.")
